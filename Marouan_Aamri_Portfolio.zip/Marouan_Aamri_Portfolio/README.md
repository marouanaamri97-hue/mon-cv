# Portfolio — Marouan Aâmri

Portfolio personnel responsive construit avec HTML, CSS et JavaScript.

## Ouvrir le site
1. Extraire le ZIP.
2. Ouvrir `index.html` dans un navigateur.
3. Pour le développement, ouvrir le dossier dans VS Code.

## Personnalisation obligatoire
- Ouvrir `script.js` et renseigner `email`, `linkedin` et `github` avec tes vrais liens.
- Dans `index.html`, remplacer les descriptions des cartes de projets par les détails de projets réellement réalisés.
- Ajouter des liens GitHub seulement après avoir publié le code.
- Vérifier les niveaux de compétences avant de partager le portfolio.

## Publication avec GitHub Pages
1. Créer un dépôt GitHub, par exemple `marouan-aamri.github.io` (si le nom est disponible et correspond à ton identifiant GitHub).
2. Ajouter les fichiers `index.html`, `style.css`, `script.js` et `README.md`.
3. Dans les paramètres du dépôt, ouvrir **Pages**.
4. Choisir la branche principale et le dossier racine, puis enregistrer.
5. Attendre la publication et ouvrir l'URL indiquée par GitHub Pages.

Aucune expérience professionnelle, adresse e-mail, URL LinkedIn ou URL GitHub n'a été inventée. Les cartes de projets sont des modèles à personnaliser.
