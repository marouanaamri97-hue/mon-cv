/*
  Portfolio de Marouan Aâmri
  Personnalise les champs ci-dessous avec tes vraies coordonnées.
  Ne publie pas de coordonnées privées si tu ne souhaites pas les rendre publiques.
*/
const portfolio = {
  email: "",       // Exemple : "marouan@example.com" — remplace par ton adresse réelle
  linkedin: "",    // Exemple : "https://www.linkedin.com/in/ton-profil"
  github: ""       // Exemple : "https://github.com/ton-identifiant"
};

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle?.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Fermer le menu" : "Ouvrir le menu");
});

navLinks?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

const contactButtons = document.getElementById("contactButtons");
const links = [
  { label: "E-mail", value: portfolio.email, href: portfolio.email ? `mailto:${portfolio.email}` : "" },
  { label: "LinkedIn", value: portfolio.linkedin, href: portfolio.linkedin },
  { label: "GitHub", value: portfolio.github, href: portfolio.github }
];

links.forEach((item) => {
  if (!item.value || !item.href) return;
  const link = document.createElement("a");
  link.href = item.href;
  link.textContent = item.label + " ↗";
  if (item.href.startsWith("http")) {
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  }
  contactButtons.appendChild(link);
});

// Apparition progressive des éléments au défilement.
const revealTargets = document.querySelectorAll(
  ".section-heading, .about-content, .skill-card, .project-card, .contact-card"
);
revealTargets.forEach((element) => element.classList.add("reveal"));

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealTargets.forEach((element) => observer.observe(element));
} else {
  revealTargets.forEach((element) => element.classList.add("visible"));
}
